import type { NavSection } from "@/config/navigation";
import { getAuthTokenKey } from "@/lib/env";

export function getMenuCacheKey(): string {
  return `${getAuthTokenKey()}_menu`;
}

function isNavSectionArray(value: unknown): value is NavSection[] {
  return Array.isArray(value) && value.every((section) => section && typeof section === "object");
}

export function readMenuCache(): NavSection[] | null {
  if (typeof window === "undefined") return null;
  const raw = localStorage.getItem(getMenuCacheKey());
  if (!raw) return null;
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!isNavSectionArray(parsed) || parsed.length === 0) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function writeMenuCache(sections: NavSection[]): void {
  if (typeof window === "undefined") return;
  if (!sections.length) return;
  localStorage.setItem(getMenuCacheKey(), JSON.stringify(sections));
}

export function clearMenuCache(): void {
  if (typeof window === "undefined") return;
  localStorage.removeItem(getMenuCacheKey());
}
